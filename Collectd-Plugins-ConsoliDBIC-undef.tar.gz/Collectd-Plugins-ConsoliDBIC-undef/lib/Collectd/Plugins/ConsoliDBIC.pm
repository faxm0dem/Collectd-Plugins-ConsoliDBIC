package Collectd::Plugins::ConsoliDBIC;

use strict;
use warnings;

use Collectd qw( :all );
use Collectd::Unixsock;
use DBIx::Class;
use Data::Dumper;

my $last_ts = time();
my $plugin_name = "consolidbic";
my %opt = (
	Interval => $interval_g,
	Hostname => $hostname_g,
	UnixSock => "/var/run/collectd/sock",
	PluginName => $plugin_name,
);
my $collectd;
my $schema;

=head1 NAME

Collectd::Plugins::ConsoliDBIC - Collectd probe to consolidate data from
collectd probes grouping by keys from a database (using a DBIC handle).

=head1 SYNOPSIS

To be used with Collectd perl

=cut

plugin_register(TYPE_CONFIG, $plugin_name, 'my_config');
plugin_register(TYPE_READ, $plugin_name, 'my_get');
plugin_register(TYPE_INIT, $plugin_name, 'my_init');

sub my_init {
	$collectd = Collectd::Unixsock -> new ($opt{UnixSock}) or return undef;
	eval "require $opt{Schema}";
	$schema   = $opt{Schema} -> connect(@opt{qw/DSN Username Password/});
	1;
}

sub my_log {
	plugin_log shift @_, join " ", "$plugin_name", @_;
}

=head1 OPTIONS

=head2 Interval

Custom interval at which the plugin will fire up.

=head2 Schema

Schema name to be used for DB connection.
Must be a DBIx::Class::Schema subclass.

=head2 DSN/Username/Password

These are the connection parameters to be passed to L<DBIx::Class::Schema/connect>.

=cut

sub recurse_config {
	my $config = shift;
	my %inter;
	my @children = @{$config -> {children}};
	if (@children) {
		for my $child (@children) {
			my @next = recurse_config ($child);
			my $key = $config -> {key};
			$key =~ s/__/./; # collectd liboconfig won't allow dots in key names
			if (defined $inter{$key}->{$next[0]} && ! ref $inter{$key}->{$next[0]}) {
				$inter{$key}->{$next[0]} = [$inter{$key}->{$next[0]},$next[1]];
			} else {
				$inter{$key}->{$next[0]} = $next[1];
			}
		}
		return %inter;
	} else {
		my $key = $config -> {key};
		$key =~ s/__/./; # collectd liboconfig won't allow dots in key names
		if (@{$config -> {values}} > 1) {
			return ($key, $config -> {values});
		} else {
			return ($key, $config -> {values} -> [0]);
		}
	}
}

sub my_config {
	my %valid_scalar_key = map { $_ => 1} qw/Interval Schema DSN Username Password ResultSet HostsFrom UnixSock DomainName PluginName Host/;
	USER: for my $child (@{$_[0] -> {children}}) {
		my $key = $child -> {key};
		if ($key =~ qr/^(Search|Match|InstanceFrom)$/) {
			($opt{$key}) = {recurse_config $_[0]}->{Plugin}->{$key};
			local $Data::Dumper::Indent = 0;
			my_log(LOG_DEBUG, "Registered option $key = ", Dumper $opt{$key});
		} else {
			VALID: for my $string (keys %valid_scalar_key) {
				if ($key =~ qr/^$string$/) {
					$opt{$key} = $child -> {values} -> [0];
					my_log(LOG_DEBUG, "Registered option $key = $opt{$key}");
					delete $valid_scalar_key{$key};
					next USER;
				}
			}
			my_log(LOG_WARNING, "Unrecognized or duplicate plugin option ".$child->{key});
		}
	}
	my $missing_opt = 0;
	for (qw/Schema DSN ResultSet HostsFrom InstanceFrom UnixSock Search Match/) {
		unless (exists $opt{$_}) {
			my_log(LOG_ERR, "Mandatory Option $_ missing");
			$missing_opt++;
		}
	}
	return undef if $missing_opt;
	for (qw/Plugin Type/) {
		unless (exists $opt{Match}->{$_}) {
			my_log(LOG_ERR, "Mandatory Option $_ missing in Match block");
			$missing_opt++;
		}
	}
	return undef if $missing_opt;
	for (qw/HostsFrom InstanceFrom/) { 
		my $ref = ref $opt{$_};
		if ($ref eq "HASH") {
			my_log(LOG_ERR, "Option $_ must be scalar or array");
			$missing_opt++;
		} elsif ($ref eq "") {
			$opt{$_} = [$opt{$_}];
		}
	}
	return undef if $missing_opt;
}

sub my_get {
	my $ts = time;
	if ($ts < $opt{Interval} + $last_ts) {
		return 1;
	}

	# first let's load into memory what collectd's got in cache
	my @listval = $collectd->listval();

	# now let's load into memory what's in the database schema
	my %listhost;
	my $rs = $schema -> resultset ($opt{ResultSet}) -> search (
		$opt{Search}->{Condition},
		$opt{Search}->{Attributes}
	);
	while (my $host = $rs -> next) {
		# retrieve hostname from DB
		my $hostname = $host;
		$hostname = $hostname -> $_ for (@{$opt{HostsFrom}});
		$hostname .= ".$opt{DomainName}" if $opt{DomainName};

		# retrieve instance name from DB
		my $instance = $host;
		$instance = $instance -> $_ for (@{$opt{InstanceFrom}});

		# now put this into hash host{instance}
		$listhost{$hostname} = $instance;
	}

	my %result;
	VALUE: for my $value (@listval) {
		# filter out unwanted values
		next unless $value -> {plugin} =~ qr/$opt{Match}->{Plugin}/;
		next unless $value -> {type}   =~ qr/$opt{Match}->{Type}/;
		if (defined $value -> {type_instance} && defined $opt{Match}->{TypeInstance}) {
			next VALUE unless $value -> {type_instance} =~ qr/$opt{Match}->{TypeInstance}/;
		}
		if (defined $value -> {plugin_instance} && defined $opt{Match}->{PluginInstance}) {
			next VALUE unless $value -> {plugin_instance} =~ qr/$opt{Match}->{PluginInstance}/;
		}

		# we have a candidate: let's see if it's in the db
		my $host = $value->{host};
		if (exists $listhost{$host}) {
			# we have a winner
			my %ident = map { $_ => $value -> {$_} } qw/host plugin plugin_instance type type_instance/;
			$result{$listhost{$host}} += $collectd->getval(%ident);
		}
	}
	while (my ($instance,$value) = each %result) {
		my %type_instance = defined $opt{Match}->{TypeInstance} ?
			(type_instance => $opt{Match}->{TypeInstance}) : ();
#		my %plugin_instance = defined $opt{Match}->{PluginInstance} ?
#			(plugin_instance => $opt{Match}->{PluginInstance}) : ();
			#$instance =~ s/ /_/g;
		my %plugin_instance = ( plugin_instance => $instance);
		my $pdv = {
			interval => $opt{Interval},
			host => $opt{Host} || $hostname_g,
			plugin => $opt{PluginName},
			type => $opt{Match}->{Type},
			%type_instance,
			%plugin_instance,
			values => [ $value ],
		};
		my_log(LOG_DEBUG, "dispatching", Dumper $pdv);
		plugin_dispatch_values ($pdv);
	}
	$last_ts = $ts;
  return 1;
}

1;

